﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Torch.ApiGenerator
{
    public interface ICodeGenerator
    {
        string Generate();
    }
}
