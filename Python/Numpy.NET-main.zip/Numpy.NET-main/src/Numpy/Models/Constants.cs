﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Numpy.Models
{
    public enum Constants
    {
        inf, neg_inf
    }
}
