﻿using System;
using System.Collections.Generic;
using System.Text;
using Python.Runtime;

namespace Numpy.Models
{
    public class Flags : PythonObject
    {
        public Flags(PyObject pyobject) : base(pyobject)
        {
        }

    }
}
