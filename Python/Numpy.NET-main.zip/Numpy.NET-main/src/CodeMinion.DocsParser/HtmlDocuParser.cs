﻿using System;

namespace CodeMinion.DocsParser
{
    public class HtmlDocuParser
    {
    }
}
