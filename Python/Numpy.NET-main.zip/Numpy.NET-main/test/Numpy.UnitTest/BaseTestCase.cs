﻿namespace Numpy.UnitTest
{
    public class BaseTestCase
    {
    }
}
